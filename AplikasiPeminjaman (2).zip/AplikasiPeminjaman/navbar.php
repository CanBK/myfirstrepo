<body>

    <div class="super_container">

        <!-- Header -->
        <header class="header d-flex flex-row" style="top: 10px;height: 70px;">
            <div class="header_content d-flex flex-row align-items-center" style="width: 100%;">
                <img src="img/logo.png" alt="" style="width: 25%;padding-left: 2%;">
                <!-- Main Navigation -->
                <nav class="main_nav_container">
                    <div class="main_nav">
                        <ul class="main_nav_list">
                            <li class="main_nav_item"><a href="index.php">Beranda</a></li>
                            <li class="main_nav_item"><a href="struktur_organisasi.php">Struktur Organisasi</a></li>
                            <li class="main_nav_item"><a href="courses.html">Peminjaman Ruangan</a></li>
                            <li class="main_nav_item"><a href="elements.html">Peminjaman Barang</a></li>
                        </ul>
                    </div>
                </nav>
            </div>

        </header>